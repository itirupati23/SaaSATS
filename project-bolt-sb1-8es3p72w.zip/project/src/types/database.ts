export interface Job {
  id: string;
  title: string;
  description: string;
  requirements: string[];
  location: string;
  type: 'full-time' | 'part-time' | 'contract';
  salary_range: string;
  created_at: string;
  department: string;
  status: 'draft' | 'published' | 'closed';
}

export interface Candidate {
  id: string;
  job_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  resume_url: string;
  status: 'new' | 'screening' | 'interview' | 'offer' | 'rejected';
  created_at: string;
  notes: string;
}